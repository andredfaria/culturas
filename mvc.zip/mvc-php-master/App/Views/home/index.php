    <div class="starter-template">
        <h1>Bem Vindos ao MVC</h1>
        <p class="lead">Projeto MVC</p>
        <a href="https://github.com/frf/mvc-php/archive/master.zip" class="btn btn-success btn-sm">GIT Download</a>
        <a href="https://github.com/frf/mvc-php" target="_blank" class="btn btn-info btn-sm">GIT Project</a>
    </div>
