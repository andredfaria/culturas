$(function() {
    $('#vl_produto').maskMoney();
});